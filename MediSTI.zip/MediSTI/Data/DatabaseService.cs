﻿
using MediSTI.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace MediSTI.Data
{
    public class DatabaseService
    {
        private SQLiteAsyncConnection _db;
        private readonly string _dbPath;

        public DatabaseService()
        {
            _dbPath = Path.Combine(FileSystem.AppDataDirectory, "MediSTI.db3");
        }

        private async Task Init()
        {
            if (_db != null) return;

            _db = new SQLiteAsyncConnection(_dbPath);

            // Crea las tablas. SQLite detectará automáticamente nuevas columnas 
            // como 'DiasSemana' si ya desinstalaste la app previa.
            await _db.CreateTableAsync<Paciente>();
            await _db.CreateTableAsync<Medicamento>();
            await _db.CreateTableAsync<Horario>();
            await _db.CreateTableAsync<Registro>();
            // En Init() agregar:
            await _db.CreateTableAsync<NotificacionId>();
        }

        // --- MÉTODOS PARA PACIENTES ---
        public async Task<List<Paciente>> GetPacientesAsync()
        {
            await Init();
            return await _db.Table<Paciente>().ToListAsync();
        }

        public async Task<int> SavePacienteAsync(Paciente paciente)
        {
            await Init();
            return paciente.Id != 0 ? await _db.UpdateAsync(paciente) : await _db.InsertAsync(paciente);
        }

        public async Task<int> DeletePacienteAsync(Paciente paciente)
        {
            await Init();
            return await _db.DeleteAsync(paciente);
        }


        // ── MEDICAMENTOS ───────────────────────────
        public async Task<List<Medicamento>> GetMedicamentosAsync(int pacienteId)
        {
            await Init();
            return await _db.Table<Medicamento>()
                .Where(m => m.PacienteId == pacienteId)
                .ToListAsync();
        }

        public async Task<int> SaveMedicamentoAsync(Medicamento m)
        {
            await Init();
            // Al retornar el ID después de insertar, permites que el ViewModel
            // sepa a qué ID vincular los nuevos horarios.
            if (m.Id == 0)
            {
                await _db.InsertAsync(m);
                return m.Id;
            }
            else
            {
                return await _db.UpdateAsync(m);
            }
        }

        public async Task<int> DeleteMedicamentoAsync(Medicamento m)
        {
            await Init();
            return await _db.DeleteAsync(m);
        }

        // ── HORARIOS ───────────────────────────────
        public async Task<List<Horario>> GetHorariosByMedicamentoAsync(int medicamentoId)
        {
            await Init(); // IMPORTANTE: Agregado para evitar errores de conexión
            return await _db.Table<Horario>()
                            .Where(h => h.MedicamentoId == medicamentoId)
                            .ToListAsync();
        }

        public async Task<int> SaveHorarioAsync(Horario h)
        {
            await Init();
            return h.Id == 0 ? await _db.InsertAsync(h) : await _db.UpdateAsync(h);
        }

        public async Task<int> DeleteHorarioAsync(Horario h)
        {
            await Init();
            return await _db.DeleteAsync(h);
        }

        // ── REGISTROS ──────────────────────────────
        public async Task<int> SaveRegistroAsync(Registro r)
        {
            await Init();
            return r.Id == 0 ? await _db.InsertAsync(r) : await _db.UpdateAsync(r);
        }

        // notificaciones 

        // Métodos nuevos al final de la clase:
        public async Task GuardarNotificacionIdAsync(NotificacionId notif)
        {
            await Init();
            await _db.InsertAsync(notif);
        }

        public async Task<List<NotificacionId>> GetNotificacionIdsAsync(int medicamentoId)
        {
            await Init();
            return await _db.Table<NotificacionId>()
                .Where(n => n.MedicamentoId == medicamentoId)
                .ToListAsync();
        }

        public async Task EliminarNotificacionIdsAsync(int medicamentoId)
        {
            await Init();
            await _db.Table<NotificacionId>()
                .Where(n => n.MedicamentoId == medicamentoId)
                .DeleteAsync();
        }

        // Dentro de tu clase DatabaseService
        public async Task<int> GuardarMuchasNotificacionesAsync(List<NotificacionId> listaNotificaciones)
        {
            // Verificamos que la lista no esté vacía
            if (listaNotificaciones == null || !listaNotificaciones.Any())
                return 0;

            try
            {
                // InsertAllAsync es el método de lote de SQLite. 
                // Es muchísimo más rápido que InsertAsync en un bucle.
                return await _db.InsertAllAsync(listaNotificaciones);
            }
            catch (Exception ex)
            {
                // Log del error si es necesario
                System.Diagnostics.Debug.WriteLine($"Error STI en inserción por lote: {ex.Message}");
                return 0;
            }
        }
    }
}