﻿using MediSTI.Data;
using Plugin.LocalNotification;
using Plugin.LocalNotification.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;

namespace MediSTI.ViewModels
{

    public class MainViewModel : BindableObject
    {
        private readonly DatabaseService _dbService;

        // Definición de los comandos que usas en el XAML
        public ICommand AlarmaRapidaCommand { get; }
        public ICommand IrAPacientesCommand { get; }
        public ICommand IrAMedicinasCommand { get; }

        public MainViewModel(DatabaseService dbService)
        {
            _dbService = dbService;

            // Inicializamos los comandos
            AlarmaRapidaCommand = new Command(async () => await EjecutarAlarmaRapida());

            // Estos comandos permiten que los botones inferiores naveguen a las otras pestañas
            IrAPacientesCommand = new Command(async () => await Shell.Current.GoToAsync("//Pacientes"));
            IrAMedicinasCommand = new Command(async () => await Shell.Current.GoToAsync("//Medicamentos"));
        }

        private async Task EjecutarAlarmaRapida()
        {
            // Verificamos permisos de notificación (Importante para Android 13+)
            if (await LocalNotificationCenter.Current.AreNotificationsEnabled() == false)
            {
                await LocalNotificationCenter.Current.RequestNotificationPermission();
            }

            string nombreAlarma = await Shell.Current.DisplayActionSheet(
     "¿Qué quieres recordar?",
     "Cancelar",
     null,
     new string[] { "Tomar Agua", "Vitamina", "Pastilla puntual" });

            if (nombreAlarma == "Cancelar" || string.IsNullOrEmpty(nombreAlarma)) return;

            var request = new NotificationRequest
            {
                NotificationId = 1337,
                Title = "MediSTI - Recordatorio Rápido",
                Description = $"Es hora de: {nombreAlarma}",
                BadgeNumber = 1,
                Schedule = new NotificationRequestSchedule
                {
                    NotifyTime = DateTime.Now.AddSeconds(10) // Prueba rápida en 10 segundos
                }
            };

            await LocalNotificationCenter.Current.Show(request);
            await Shell.Current.DisplayAlert("¡Listo!", $"Te avisaremos en 10 segundos sobre: {nombreAlarma}", "Entendido");
        }
    }

}
