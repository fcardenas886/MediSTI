using Microsoft.Maui.Controls.PlatformConfiguration;
// Agregar arriba del archivo:
using Microsoft.Maui.Storage;

#if ANDROID
using Android.Content;
#endif


namespace MediSTI.Views;

public partial class HomePage : ContentPage
{
	public HomePage(ViewModels.MainViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;

        VersionLabel.Text = $"v{Microsoft.Maui.ApplicationModel.AppInfo.Current.VersionString}";
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        // Solo en Xiaomi y solo primera vez
#if ANDROID
    if (Android.OS.Build.Manufacturer.ToLower().Contains("xiaomi"))
    {
        var yaVio = Preferences.Get("PermisosMostrados", false);
        if (!yaVio)
        {
            MostrarBannerPermisos.IsVisible = true;
        }
    }
#endif
    }

    private void OnConfigurarPermisos(object sender, EventArgs e)
    {
#if ANDROID
    try
    {
        var intent = new Intent();
        intent.SetComponent(new ComponentName("com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"));
        
        var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity;
        activity.StartActivity(intent);
        
        Preferences.Set("PermisosMostrados", true);
        MostrarBannerPermisos.IsVisible = false;
    }
    catch { }
#endif
    }
}